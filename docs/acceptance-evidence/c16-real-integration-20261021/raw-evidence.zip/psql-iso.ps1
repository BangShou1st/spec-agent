# Helper: run psql against THIS round's isolated database only.
# Usage: psql-iso.ps1 -Sql "select 1"   |   psql-iso.ps1 -SqlFile /path/to.sql
param(
  [string]$Sql = '',
  [string]$SqlFile = '',
  [string]$DbName = 'spec_agent_iso_20261021',
  [string]$DbUser = 'spec_agent_iso_20261021',
  [switch]$NoHeader
)
$ErrorActionPreference = 'Stop'
$env:PATH = "E:\DevTools\DockerDesktop\resources\bin;$env:PATH"
$ctr = 'spec-agent-iso-20261021-postgres'
$psqlArgs = @('exec','-i',$ctr,'psql','-U',$DbUser,'-d',$DbName,'-v','ON_ERROR_STOP=1')
if ($NoHeader) { $psqlArgs += '-tA' }
if ($Sql)     { $psqlArgs += @('-c',$Sql) }
if ($SqlFile) {
    # The container cannot see host paths: stream the file into psql on stdin.
    Get-Content -LiteralPath $SqlFile -Raw | & docker @psqlArgs
} else {
    & docker @psqlArgs
}
exit $LASTEXITCODE
