# Shared environment for the 2026-10-21 isolated acceptance round.
# Dot-source this before any gradle/java run:  . 'E:\project\spec-agent\scratch\iso-20261021\env.ps1'
# Every value points at THIS round's dedicated container only.
$ErrorActionPreference = 'Stop'
$env:PATH = "E:\DevTools\DockerDesktop\resources\bin;$env:PATH"

$base   = 'E:\project\spec-agent\scratch\iso-20261021'
$envMap = @{}
Get-Content (Join-Path $base 'db.env') | ForEach-Object {
    if ($_ -match '^([^=]+)=(.*)$') { $envMap[$matches[1]] = $matches[2] }
}
$DbUser = $envMap['POSTGRES_USER']
$DbPass = $envMap['POSTGRES_PASSWORD']

# The guarded Spring test context uses SPEC_AGENT_TEST_DB_*; the standalone
# application uses SPEC_AGENT_DB_*/SPRING_DATASOURCE_*. All point at the same
# isolated server; the database name satisfies the project's own isolation gate.
$env:SPEC_AGENT_TEST_DB_URL            = 'jdbc:postgresql://127.0.0.1:55432/spec_agent_p3b_live_iso20261021'
$env:SPEC_AGENT_TEST_DB_USERNAME       = $DbUser
$env:SPEC_AGENT_TEST_DB_PASSWORD       = $DbPass
$env:SPEC_AGENT_TEST_DB_SERVER_ADDRESS = '172.19.0.2/32'
$env:SPEC_AGENT_TEST_DB_SERVER_PORT    = '5432'

$env:SPEC_AGENT_DB_HOST     = '127.0.0.1'
$env:SPEC_AGENT_DB_PORT     = '55432'
$env:SPEC_AGENT_DB_NAME     = 'spec_agent_p3b_live_iso20261021'
$env:SPEC_AGENT_DB_USER     = $DbUser
$env:SPEC_AGENT_DB_PASSWORD = $DbPass

$env:SPRING_DATASOURCE_URL      = $env:SPEC_AGENT_TEST_DB_URL
$env:SPRING_DATASOURCE_USERNAME = $DbUser
$env:SPRING_DATASOURCE_PASSWORD = $DbPass
$env:SPRING_FLYWAY_URL          = $env:SPEC_AGENT_TEST_DB_URL
$env:SPRING_FLYWAY_USER         = $DbUser
$env:SPRING_FLYWAY_PASSWORD     = $DbPass

# Deterministic, round-scoped internal secret shared by the Host and the Python brain.
function New-RoundScopedSecret {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        $bytes = New-Object byte[] 32
        [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
        $value = [Convert]::ToBase64String($bytes)
        Set-Content -LiteralPath $Path -Value $value -Encoding ascii -NoNewline
    }
    if (-not (Test-Path -LiteralPath $Path)) { throw "secret file was not created: $Path" }
    return (Get-Content -LiteralPath $Path -Raw).Trim()
}
$env:SPEC_AGENT_BRAIN_INTERNAL_SECRET = New-RoundScopedSecret (Join-Path $base 'brain-internal-secret.txt')

# Round-scoped master key so the isolated DB never depends on the shared
# backend/data/secret-master.key and never writes into the developer tree.
$env:SPEC_AGENT_SECRET_MASTER_KEY = New-RoundScopedSecret (Join-Path $base 'master-key.b64')

# Keep runtime-written artifacts (skill mirror) inside this round's scratch dir.
$env:SPEC_AGENT_SKILL_LOCAL_MIRROR_ROOT = Join-Path $base 'skill-mirror'

Write-Host "[iso-env] target=$($env:SPEC_AGENT_TEST_DB_URL) user=$DbUser server=172.19.0.2/32:5432"
