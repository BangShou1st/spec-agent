# Scenario B (process level): the REAL Spring Boot application must refuse to start
# when the V99 guard detects an existing binding that V99 would destroy.
#
# 1. create a fresh scenario database
# 2. boot the product with --spring.flyway.target=98  -> real historical baseline
# 3. seed a synthetic in-flight run that already owns a valid binding digest
# 4. boot the product again with the normal migration chain -> must fail closed
# 5. verify: V99 not recorded, the binding is preserved, the app never became healthy
$ErrorActionPreference = 'Stop'
$base = 'E:\project\spec-agent\scratch\iso-20261021'
. (Join-Path $base 'env.ps1')

$db  = 'spec_agent_p3b_live_iso20261021_migb_boot'
$psq = Join-Path $base 'psql-iso.ps1'

Write-Host '== step 1: create scenario database =='
& $psq -Sql "drop database if exists $db with (force)" | Out-Null
& $psq -Sql "create database $db" | Out-Null

Write-Host '== step 2: boot with --spring.flyway.target=98 (real historical baseline) =='
& (Join-Path $base 'run-host.ps1') -Port 18082 -Name migb-boot-v98 -WaitSeconds 240 -DbName $db `
    -Arg '--spring.flyway.target=98' 
if ($LASTEXITCODE -ne 0) { throw 'baseline boot failed' }
& (Join-Path $base 'stop-host.ps1') -Name migb-boot-v98 -Force 
Start-Sleep -Seconds 2

Write-Host '== step 3: seed a synthetic in-flight run with an existing valid binding =='
$org  = [guid]::NewGuid().ToString()
$usr  = [guid]::NewGuid().ToString()
$prj  = [guid]::NewGuid().ToString()
$run  = [guid]::NewGuid().ToString()
$digest = 'd3adb33f' + ('0' * 56)
$seed = @"
insert into organizations(id,name) values('$org','v99 guard boot org');
insert into app_users(id,display_name) values('$usr','v99 guard boot user');
insert into projects(id,title,org_id,created_by) values('$prj','v99 guard boot project','$org','$usr');
insert into agent_runs(id,project_id,trigger_type,status,created_at) values('$run','$prj','initial_requirement','model_called',CURRENT_TIMESTAMP);
update agent_runs set model_binding_fingerprint='$digest' where id='$run';
"@
$seedFile = Join-Path $base 'seed-v99-guard.sql'
Set-Content -LiteralPath $seedFile -Value $seed -Encoding ascii
& $psq -DbName $db -SqlFile $seedFile 
& $psq -DbName $db -Sql "select id,status,trim(model_binding_fingerprint) from agent_runs" 

Write-Host '== step 4: boot the product with the normal chain -> must fail closed =='
& (Join-Path $base 'run-host.ps1') -Port 18082 -Name migb-boot-blocked -WaitSeconds 180 -DbName $db -ExpectFail 
$blockedExit = $LASTEXITCODE

$log = Join-Path $base 'run-migb-boot-blocked\app.log'
$err = Join-Path $base 'run-migb-boot-blocked\app.err.log'
$hits = @()
foreach ($f in @($log, $err)) {
    if (Test-Path -LiteralPath $f) {
        $hits += Select-String -Path $f -Pattern 'V99_BINDING_OVERWRITE_BLOCKED|V99_BINDING_GUARD|Migration of schema|FlywayException' -ErrorAction SilentlyContinue
    }
}
Write-Host "== guard evidence hits: $($hits.Count) =="
$hits | Select-Object -First 8 | ForEach-Object { Write-Host $_.Line }

Write-Host '== step 5: verify the database state =='
& $psq -DbName $db -Sql "select version,success from flyway_schema_history order by installed_rank desc limit 3" 
& $psq -DbName $db -Sql "select id,status,trim(model_binding_fingerprint) fp from agent_runs" 

$history = & $psq -DbName $db -NoHeader -Sql "select count(*) from flyway_schema_history where version='99'"
$binding = & $psq -DbName $db -NoHeader -Sql "select trim(model_binding_fingerprint) from agent_runs where id='$run'"
Write-Host "V99 recorded rows: $history"
Write-Host "binding after the blocked upgrade: $binding"

$ok = ($hits.Count -gt 0) -and ([string]$history).Trim() -eq '0' -and ([string]$binding).Trim() -eq $digest
if (-not $ok) { Write-Host 'SCENARIO_B_BOOT: FAILED'; exit 1 }
Write-Host 'SCENARIO_B_BOOT: PASSED - the product refused to start and the binding survived'
exit 0
