# Boots the real Spring Boot application against THIS round's isolated database.
# Usage: run-host.ps1 -Port 18081 -Name a1 [-WaitSeconds 240] [-Arg "..."] [-ExpectFail]
param(
  [int]$Port = 18081,
  [string]$Name = 'a1',
  [int]$WaitSeconds = 240,
  [string]$Arg = '',
  [string]$DbName = 'spec_agent_p3b_live_iso20261021',
  [switch]$ExpectFail,
  [switch]$NoWait
)
$ErrorActionPreference = 'Stop'
$base = 'E:\project\spec-agent\scratch\iso-20261021'
. (Join-Path $base 'env.ps1')

# Point this process at one scenario database inside the isolated server.
$env:SPEC_AGENT_DB_NAME = $DbName
$env:SPRING_DATASOURCE_URL = "jdbc:postgresql://127.0.0.1:55432/$DbName"
$env:SPRING_FLYWAY_URL = $env:SPRING_DATASOURCE_URL

$runDir = Join-Path $base "run-$Name"
New-Item -ItemType Directory -Force -Path $runDir | Out-Null
$log    = Join-Path $runDir 'app.log'
$errLog = Join-Path $runDir 'app.err.log'
$jar    = 'E:\project\spec-agent\backend\build\libs\spec-agent-backend-0.0.1-SNAPSHOT.jar'

$env:SERVER_PORT    = "$Port"
$env:SERVER_ADDRESS = '127.0.0.1'
# Product background workers stay off unless this round explicitly turns them on.
if (-not $env:SPEC_AGENT_BRAIN_WORKER_ENABLED)   { $env:SPEC_AGENT_BRAIN_WORKER_ENABLED   = 'false' }
if (-not $env:SPEC_AGENT_EMBEDDING_WORKER_ENABLED){ $env:SPEC_AGENT_EMBEDDING_WORKER_ENABLED= 'false' }

foreach ($f in @($log, $errLog)) {
    if (Test-Path -LiteralPath $f) {
        try { Remove-Item -LiteralPath $f -Force -ErrorAction Stop }
        catch { Write-Host "[run-$Name] previous log still locked: $($_.Exception.Message)" }
    }
}

# Stop leftovers from an earlier attempt of this round so the log file is free.
Get-CimInstance Win32_Process -Filter "Name='java.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like '*spec-agent-backend-0.0.1-SNAPSHOT.jar*' } |
    ForEach-Object {
        Write-Host "[run-$Name] stopping stale host pid=$($_.ProcessId)"
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }
Start-Sleep -Milliseconds 500

$javaArgs = @('-jar', $jar)
if ($Arg) { $javaArgs += ($Arg -split '\s+') }

$proc = Start-Process -FilePath 'java' -ArgumentList $javaArgs -WorkingDirectory $runDir `
        -RedirectStandardOutput $log -RedirectStandardError $errLog -PassThru -WindowStyle Hidden
$proc.Id | Set-Content -LiteralPath (Join-Path $runDir 'app.pid')

if ($NoWait) {
    Write-Host "[run-$Name] started pid=$($proc.Id) port=$Port log=$log"
    return
}

$deadline = (Get-Date).AddSeconds($WaitSeconds)
$healthy = $false
$exited  = $false
while ((Get-Date) -lt $deadline) {
    if ($proc.HasExited) { $exited = $true; break }
    try {
        $resp = Invoke-WebRequest -Uri "http://127.0.0.1:$Port/actuator/health" -TimeoutSec 3 -UseBasicParsing
        if ($resp.StatusCode -eq 200) { $healthy = $true; break }
    } catch { }
    Start-Sleep -Seconds 2
}

if ($ExpectFail) {
    if (-not $exited) {
        Write-Host "[run-$Name] UNEXPECTED: process still alive (pid=$($proc.Id)) but failure was expected"
        Get-Content -LiteralPath $log -Tail 40 -ErrorAction SilentlyContinue
        exit 3
    }
    Write-Host "[run-$Name] EXPECTED FAILURE observed, exitCode=$($proc.ExitCode)"
    exit 0
}
if ($exited) {
    Write-Host "[run-$Name] EXITED code=$($proc.ExitCode)"
    Write-Host '---- stdout tail ----'; Get-Content -LiteralPath $log -Tail 60 -ErrorAction SilentlyContinue
    Write-Host '---- stderr tail ----'; Get-Content -LiteralPath $errLog -Tail 40 -ErrorAction SilentlyContinue
    exit 1
}
if (-not $healthy) {
    Write-Host "[run-$Name] NOT HEALTHY within $WaitSeconds s (pid=$($proc.Id) alive)"
    Write-Host '---- stdout tail ----'; Get-Content -LiteralPath $log -Tail 60 -ErrorAction SilentlyContinue
    Write-Host '---- stderr tail ----'; Get-Content -LiteralPath $errLog -Tail 40 -ErrorAction SilentlyContinue
    exit 2
}
Write-Host "[run-$Name] HEALTHY pid=$($proc.Id) port=$Port log=$log"
exit 0
