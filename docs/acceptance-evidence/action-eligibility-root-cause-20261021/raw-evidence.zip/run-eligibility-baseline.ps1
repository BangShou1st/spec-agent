# Runs the three ActionEligibility integration classes against a dedicated
# database inside the isolated server, for an independent baseline check.
# Usage: run-eligibility-baseline.ps1 -Worktree E:\project\baseline-ede535e -Database spec_agent_p3b_live_base20261021
param(
  [Parameter(Mandatory = $true)][string]$Worktree,
  [Parameter(Mandatory = $true)][string]$Database
)
$ErrorActionPreference = 'Stop'
$base = 'E:\project\spec-agent\scratch\iso-20261021'
. (Join-Path $base 'env.ps1')

$envFile = Join-Path $base 'db.env'
$envMap = @{}
Get-Content $envFile | ForEach-Object { if ($_ -match '^([^=]+)=(.*)$') { $envMap[$matches[1]] = $matches[2] } }
$DbUser = $envMap['POSTGRES_USER']
$DbPass = $envMap['POSTGRES_PASSWORD']

$url = "jdbc:postgresql://127.0.0.1:55432/$Database"
$env:SPEC_AGENT_TEST_DB_URL = $url
$env:SPEC_AGENT_TEST_DB_USERNAME = $DbUser
$env:SPEC_AGENT_TEST_DB_PASSWORD = $DbPass
$env:SPEC_AGENT_TEST_DB_SERVER_ADDRESS = '172.19.0.2/32'
$env:SPEC_AGENT_TEST_DB_SERVER_PORT = '5432'
$env:SPRING_DATASOURCE_URL = $url
$env:SPRING_DATASOURCE_USERNAME = $DbUser
$env:SPRING_DATASOURCE_PASSWORD = $DbPass
$env:SPRING_FLYWAY_URL = $url
$env:SPRING_FLYWAY_USER = $DbUser
$env:SPRING_FLYWAY_PASSWORD = $DbPass

Push-Location (Join-Path $Worktree 'backend')
try {
    .\gradlew.bat --offline testDatabaseIntegration -PdatabaseIntegration=true `
        --tests "com.specagent.eval.ActionEligibilityEnforcementIntegrationTest" `
        --tests "com.specagent.eval.P3BC09AmbiguousGateEnforcementTest" `
        --tests "com.specagent.eval.P3BEnforcedCapabilityNecessityTest" `
        --console=plain 2>&1 | Select-String -Pattern 'FAILED|BUILD |tests completed' | ForEach-Object { $_.Line }
    $exit = $LASTEXITCODE
} finally { Pop-Location }

$xml = Join-Path $Worktree 'backend\build\test-results\testDatabaseIntegration'
Write-Host "--- per class results ---"
foreach ($file in Get-ChildItem $xml -Filter 'TEST-*.xml' -ErrorAction SilentlyContinue) {
    $x = [xml](Get-Content $file.FullName)
    Write-Host ("{0}: tests={1} failures={2} errors={3}" -f $x.testsuite.name, $x.testsuite.tests, $x.testsuite.failures, $x.testsuite.errors)
    foreach ($tc in $x.testsuite.testcase) {
        if ($tc.failure -or $tc.error) {
            $m = (($tc.failure.message) -split "`n" | Select-Object -First 3) -join ' | '
            Write-Host ("   FAIL {0} :: {1}" -f $tc.name, $m)
        }
    }
}
exit $exit
