# Extracts the three failing JUnit XMLs out of the committed evidence zip and
# prints a precise per-test failure report (assertion, cause, product frames).
$ErrorActionPreference = 'Stop'
$repo = 'E:\project\spec-agent'
$out  = Join-Path $repo 'scratch\iso-20261021\ae9'
New-Item -ItemType Directory -Force -Path $out | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipPath = Join-Path $repo 'docs\acceptance-evidence\c16-real-integration-20261021\raw-evidence.zip'
$zip = [IO.Compression.ZipFile]::OpenRead($zipPath)
foreach ($entry in $zip.Entries) {
    if ($entry.FullName -match 'junit-testDatabaseIntegration/TEST-com\.specagent\.eval\.(ActionEligibilityEnforcementIntegrationTest|P3BC09AmbiguousGateEnforcementTest|P3BEnforcedCapabilityNecessityTest)\.xml$') {
        $target = Join-Path $out ([IO.Path]::GetFileName($entry.FullName))
        [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $true)
        Write-Host "extracted $target ($($entry.Length) bytes)"
    }
}
$zip.Dispose()

foreach ($file in Get-ChildItem $out -Filter 'TEST-*.xml') {
    Write-Host ""
    Write-Host "################ $($file.Name) ################"
    $xml = [xml](Get-Content -LiteralPath $file.FullName)
    Write-Host ("suite: tests={0} failures={1} errors={2} skipped={3} time={4}s" -f `
        $xml.testsuite.tests, $xml.testsuite.failures, $xml.testsuite.errors, $xml.testsuite.skipped, $xml.testsuite.time)
    foreach ($case in $xml.testsuite.testcase) {
        $failure = $case.failure
        if (-not $failure) { $failure = $case.error }
        if (-not $failure) {
            Write-Host "PASS  $($case.name)  ($($case.time)s)"
            continue
        }
        Write-Host ""
        Write-Host "FAIL  $($case.name)  type=$($failure.type) time=$($case.time)s"
        Write-Host "--- message ---"
        Write-Host $failure.message
        $text = $failure.'#text'
        if ($text) {
            Write-Host "--- product frames ---"
            ($text -split "`n" | Where-Object { $_ -match 'com\.specagent' } | Select-Object -First 8) | ForEach-Object { Write-Host $_.Trim() }
        }
    }
}
